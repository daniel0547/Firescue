let latitude=-20.081084488580498;
let longitude=-44.21941280364991

//Definição da Layer
let baseLayer = L.tileLayer(
    'http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{
      maxZoom: 18,
			minZoom: 16
    }
);

//Definição do mapa
let map = new L.Map('map', {
  center: new L.LatLng(latitude, longitude),
  zoom: 16,
  layers: [baseLayer]
});

function buildzones(){
	for(let y=bot_left_lat, y_index=0;y<top_right_lat;y+=lado+lado/2, y_index++){
		zones[y_index]=[];
		for(let x=bot_left_lng, x_index=0;x<top_right_lng;x+=altura, x_index++){
			if(y_index%2==0 && x_index==0){
				x+=altura/2;
			}
			let latlngs = [[y, x],[y+lado, x],[y+lado+lado/2, x+altura/2],[y+lado, x+altura],[y, x+altura],[y-lado/2, x+altura/2]];
			if(Math.random()<0.01){
				let polygon = L.polygon(latlngs, {color: 'red', stroke: false, fillOpacity: 0.5}).addTo(map);
				polygon.bindPopup("y_index: "+y_index+" x_index: "+x_index);
				polygon.on('click', function (e) {
	    		this.openPopup();
				});
				zones[y_index][x_index]={y_index: y_index, x_index: x_index, onfire: 1, polygon: polygon};
			}
			else{
				let polygon = L.polygon(latlngs, {color: 'green',stroke: false, fillOpacity: 0.5}).addTo(map);
				polygon.bindPopup("y_index: "+y_index+" x_index: "+x_index);
				polygon.on('click', function (e) {
	    		this.openPopup();
				});
				zones[y_index][x_index]={y_index: y_index, x_index: x_index, onfire: 0, polygon: polygon};
			}
		}
	}
}


function updateWind(){
	let minlat=Math.min(top_right_lat,bot_left_lat);
	let maxlat=Math.max(top_right_lat,bot_left_lat);
	let minlng=Math.min(top_right_lng,bot_left_lng);
	let maxlng=Math.max(top_right_lng,bot_left_lng);
	let lat=minlat+((maxlat-minlat)/2);
	let lng=minlng+((maxlng-minlng)/2);
	$.ajax({
	    type: 'GET',
	    url: 'https://api.openweathermap.org/data/2.5/weather?lat='+lat+'&lon='+lng+'&APPID=94abcf122db918453f8c117b70a82e83',
	    success: function(data) {
				windspeed=data["wind"].speed
				winddeg=data["wind"].deg
				let minspeed=0;
				let maxspeed=100;
				let minsize=30;
				let maxsize=200;
				let sizestep=(maxsize-minsize)/(maxspeed-minspeed);
				const size=minsize+(windspeed-minspeed)*sizestep;
				let windIcon = new L.icon({iconUrl: 'static/images/arrow.png',iconSize: [size,size], iconAnchor: [size/2,size/2]});
				if(windmarker){
					map.removeLayer(windmarker);
				}
				windmarker= L.marker([lat,lng],{icon: windIcon, rotationAngle: (winddeg), opacity: 0.7}).addTo(map);
				updateFireAreas();
			}
	});
}

function updateFireAreas(){
	for(let i=0;i<zones.length;i++){
		for(let j=0;j<zones[i].length;j++){
			if(zones[i][j].onfire==1 && i%2==0){
				if(winddeg>=0 && winddeg<60){
					zones[i-1][j].onfire=0.5;
					zones[i-1][j].polygon.setStyle({fillColor: 'yellow'});
				}
				if(winddeg>=60 && winddeg<120){
					zones[i][j-1].onfire=0.5;
					zones[i][j-1].polygon.setStyle({fillColor: 'yellow'});
				}
				if(winddeg>=120 && winddeg<180){
					zones[i+1][j].onfire=0.5;
					zones[i+1][j].polygon.setStyle({fillColor: 'yellow'});
				}
				if(winddeg>=180 && winddeg<240){
					zones[i+1][j+1].onfire=0.5;
					zones[i+1][j+1].polygon.setStyle({fillColor: 'yellow'});
				}
				if(winddeg>=240 && winddeg<300){
					zones[i][j+1].onfire=0.5;
					zones[i][j+1].polygon.setStyle({fillColor: 'yellow'});
				}
				if(winddeg>=300 && winddeg<360){
					zones[i-1][j+1].onfire=0.5;
					zones[i-1][j+1].polygon.setStyle({fillColor: 'yellow'});
				}
			}
			if(zones[i][j].onfire==1 && i%2!=0){
				if(winddeg>=0 && winddeg<60){
					zones[i-1][j-1].onfire=0.5;
					zones[i-1][j-1].polygon.setStyle({fillColor: 'yellow'});
				}
				if(winddeg>=60 && winddeg<120){
					zones[i][j-1].onfire=0.5;
					zones[i][j-1].polygon.setStyle({fillColor: 'yellow'});
				}
				if(winddeg>=120 && winddeg<180){
					zones[i+1][j-1].onfire=0.5;
					zones[i+1][j-1].polygon.setStyle({fillColor: 'yellow'});
				}
				if(winddeg>=180 && winddeg<240){
					zones[i+1][j].onfire=0.5;
					zones[i+1][j].polygon.setStyle({fillColor: 'yellow'});
				}
				if(winddeg>=240 && winddeg<300){
					zones[i][j+1].onfire=0.5;
					zones[i][j+1].polygon.setStyle({fillColor: 'yellow'});
				}
				if(winddeg>=300 && winddeg<360){
					zones[i-1][j].onfire=0.5;
					zones[i-1][j].polygon.setStyle({fillColor: 'yellow'});
				}
			}
		}
	}
}

function getNeighbor(n_neighbor, i,j){
	if(i%2==0){
		if(n_neighbor==0){
			return [i-1, j];
		}
		if(n_neighbor==1){
			return [i,j-1];
		}
		if(n_neighbor==2){
			return [i+1,j];
		}
		if(n_neighbor==3){
			return [i+1, j+1];
		}
		if(n_neighbor==4){
			return [i, j+1];
		}
		if(n_neighbor==5){
			return [i-1, j+1];
		}
	}
	if(i%2!=0){
		if(n_neighbor==0){
			return [i-1, j-1];
		}
		if(n_neighbor==1){
			return [i, j-1];
		}
		if(n_neighbor==2){
			return [i+1,j-1];
		}
		if(n_neighbor==3){
			return [i+1, j];
		}
		if(n_neighbor==4){
			return [i, j+1];
		}
		if(n_neighbor==5){
			return [i-1, j];
		}
	}
}

function getGraph(){
	let graph=[];
	zones.forEach((element)=>{
		element.forEach((zone)=>{
			for(let n=0;n<5;n++){
				neighbor=getNeighbor(n,zone.y_index, zone.x_index);
				if(!graph[zone.y_index*zones.length+x_index]){
					graph[zone.y_index*zones.length+x_index]=[];
				}
				graph[zone.y_index*zones.length+x_index][neighbor[0]*zones.length+neighbor[1]]=1;
				if(!graph[neighbor[0]*zones.length+neighbor[1]]){
					graph[neighbor[0]*zones.length+neighbor[1]]=[];
				}
				graph[neighbor[0]*zones.length+neighbor[1]][zone.y_index*zones.length+x_index]=1;
			}
		});
	});
	return graph;
}

const interval = setInterval(function() {
   updateWind();
 }, 10000);


bot_left_lat=-20.086989267846164;
bot_left_lng=-44.22956228256226;

top_right_lat=-20.07511902492345;
top_right_lng=-44.20857667922974;

node_size=15;
node_cat=(node_size*Math.sqrt(3));

lado=metersdistance2degrees(node_size);
altura=metersdistance2degrees(node_cat);
let zones=[];
buildzones();

let winddeg=0;
let windspeed=0;
let windmarker=0;
updateWind();
//transformações
function degreedistance2meters(degree){
  return degree*111111;
}

function metersdistance2degrees(meters){
  return meters/111111;
}
